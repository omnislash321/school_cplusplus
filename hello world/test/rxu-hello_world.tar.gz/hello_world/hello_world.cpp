//------------------------------------------------------------------------------
// Project Name: Hello World
// Written By: Roberto Hong Xu Kuang
// Last Modified: 10/09/14
//------------------------------------------------------------------------------
#include <iostream>

using namespace std;

int main(){

   cout << "Hello World!";
   return 0;
}
